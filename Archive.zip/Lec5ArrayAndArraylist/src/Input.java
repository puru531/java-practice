public class Input {
    public static void main(String[] args) {

    }
}
