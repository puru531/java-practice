import java.util.Scanner;

public class Q4Calculator {
    public static void main(String[] args) {
        //Take in two numbers and an operator (+, -, *, /) and calculate the value. (Use if conditions)
        Scanner sc = new Scanner(System.in);
        System.out.println("------------- Calculator using + - * / ---------------");
        System.out.println("Enter the operator (+ - * /) : ");
    }
}
